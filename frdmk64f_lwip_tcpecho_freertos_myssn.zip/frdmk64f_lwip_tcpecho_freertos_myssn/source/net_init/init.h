/*
 * init.h
 *
 *  Created on: 17 sep 2022
 *      Author: luisf
 */

#ifndef INITS_INIT_H_
#define INITS_INIT_H_

#include "init_interface.h"
#include "init_config.h"

void net_conect(void);


#endif /* INITS_INIT_H_ */
