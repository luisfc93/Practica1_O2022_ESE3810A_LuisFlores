/*
 * init_interface.h
 *
 *  Created on: 17 sep 2022
 *      Author: luisf
 */

#ifndef NET_INIT_INIT_INTERFACE_H_
#define NET_INIT_INIT_INTERFACE_H_



#endif /* NET_INIT_INIT_INTERFACE_H_ */
