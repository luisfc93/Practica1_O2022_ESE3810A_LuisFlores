/*
 * aes_and_crc.h
 *
 *  Created on: 17 sep 2022
 *      Author: luisf
 */

#ifndef CRYPTO_AES_AND_CRC_H_
#define CRYPTO_AES_AND_CRC_H_

#include "aes_and_crc_config.h"
#include "aes_and_crc_interface.h"
#include "aes.h"
#include "fsl_crc.h"
#include "aes_and_crc_interface.h"
#include "aes_and_crc.h"
#include "aes_and_crc_config.h"

void InitCrc32(CRC_Type *base, uint32_t seed);


#endif /* CRYPTO_AES_AND_CRC_H_ */
