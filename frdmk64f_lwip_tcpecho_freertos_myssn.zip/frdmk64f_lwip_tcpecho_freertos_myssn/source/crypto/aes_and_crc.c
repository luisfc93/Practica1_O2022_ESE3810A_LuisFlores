/*
 * aes_and_csc.c
 *
 *  Created on: 17 sep 2022
 *      Author: luisf
 */

#include "aes_and_crc.h"
#include "MK64F12.h"
#include "fsl_debug_console.h"
#include "fsl_common.h"
#include "def.h"
#include "aes_and_crc_interface.h"
#include "aes_and_crc.h"
#include "aes_and_crc_config.h"

#include "lwip/sys.h"
#include "lwip/api.h"
#include "arch/sys_arch.h"
#include "stdbool.h"

/* Padded variables and array */
size_t padded_len, string_len;
uint8_t padded_msg[512] = {0};
uint8_t encrypted_msg[512] = {0};
/* CRC data */
CRC_Type *base = CRC0;
uint32_t crc_send;
uint32_t checkCrc32;
/*AES data */
uint8_t key[] = KEY;
uint8_t iv[]  = IV;
struct AES_ctx ctx;


/*!
 * @brief Init for CRC-32.
 * @details Init CRC peripheral module for CRC-32 protocol.
 *          width=32 poly=0x04c11db7 init=0xffffffff refin=true refout=true xorout=0xffffffff check=0xcbf43926
 *          name="CRC-32"
 *          http://reveng.sourceforge.net/crc-catalogue/
 */
void InitCrc32(CRC_Type *base, uint32_t seed)
{
    crc_config_t config;

    config.polynomial         = 0x04C11DB7U;
    config.seed               = seed;
    config.reflectIn          = true;
    config.reflectOut         = true;
    config.complementChecksum = true;
    config.crcBits            = kCrcBits32;
    config.crcResult          = kCrcFinalChecksum;

    CRC_Init(base, &config);
}

bool aescrc_receive_task(void *arg, void *ptrdata)
{
		PRINTF("\nTesting receive\r");
	/* Init the AES context structure */
		AES_init_ctx_iv(&ctx, key, iv);

		/* Calculo de longitud del mensaje recibido */
		string_len = strlen(arg);
		/* Se calcula en que posicion empieza nuestro CRC*/
		uint8_t crc_pos = string_len - sizeof(uint32_t);
		/* Se declara nuestro CRC donde obtendermos posteriormente su valro real */
		uint32_t crc = 0;
		/* Pasamos a nuestra variable de crc nuestro valor actual del CRC*/
		memcpy(&crc, (uint8_t *)&arg[crc_pos], sizeof(uint32_t));

		PRINTF("Encrypted Message Received no CRC: ");
		memcpy(padded_msg, arg, crc_pos);
		for(int x=0; x<crc_pos; x++) {
					PRINTF("0x%02x,", padded_msg[x]);
				}
				PRINTF("\r\n");


		/* Se invierte el valor los datos del CRC */
		lwip_htonl(crc);
		/*Se inicializa el CRC */
	    InitCrc32(base, 0xFFFFFFFFU);
	    /* Se manda los datos del CRC de nuestro mensaje */
	    CRC_WriteData(base, (uint8_t *)&padded_msg[0], string_len-sizeof(uint32_t));
	    /* Se calcula el CRC*/
	    checkCrc32 = CRC_Get32bitResult(base);
	    PRINTF("CRC-32 calculated: 0x%02x\r\n", checkCrc32);
	    PRINTF("CRC-32 taken from message: 0x%02x\r", crc);
	    /*Se checa si el CRC que sacamos coincide con el CRC calculado y desencriptamos la información */
	    if(crc == checkCrc32){
	    	AES_CBC_decrypt_buffer(&ctx, padded_msg,  string_len-sizeof(uint32_t));
	    	PRINTF("\nTesting AES128 Decrypt\r");
	    	PRINTF("Decrypted Message, no CRC: ");
	    	for(int x=0; x<string_len-sizeof(uint32_t); x++) {
	    		PRINTF("0x%02x,", padded_msg[x]);

	    	}
	    	PRINTF("\r\n");
	    	memset(ptrdata, 0 ,string_len);
	    	memcpy(ptrdata, padded_msg, string_len-sizeof(uint32_t));
	    	return 1;
	    }
	    else{
	    	return 0;
	    }


}


void aescrc_send_task(void *arg, void *ptrdata, struct netconn *newconn)
{

	err_t err;

	PRINTF("\nTesting send\r");
	// Init the AES context structure
	AES_init_ctx_iv(&ctx, key, iv);

	string_len = strlen(arg);

	// To encrypt an array its length must be a multiple of 16 so we add zeros
	padded_len = string_len + (16 - (string_len%16) );

	/*Se copia el dato recibido a nuestro buffer padded_msg */
	memcpy(padded_msg, arg, string_len);
	/* Se encripta el mensaje*/
	AES_CBC_encrypt_buffer(&ctx, padded_msg, padded_len);
	PRINTF("Encrypted Message no CRC: ");
		for(int x=0; x<padded_len; x++) {
			PRINTF("0x%02x,", padded_msg[x]);
		}
		PRINTF("\r\n");

	/*Se inicializa el CRC */
	InitCrc32(base, 0xFFFFFFFFU);
	/* Se añade el CRC  anuestro padded_msg */
    CRC_WriteData(base, (uint8_t *)&padded_msg[0], padded_len);//Ver que apuntador entra ahi
	/* Se guarda dato para enviar */
    crc_send = CRC_Get32bitResult(base);
    /* Se invierte el valor los datos del CRC */
    lwip_htonl(crc_send);
    /*Se imprime el valor del crc*/
    PRINTF("CRC-32: 0x%02x\r\n", crc_send);
    /* Se añade el CRC al nuestro padded_msg*/
	memcpy(&padded_msg[padded_len], &crc_send, sizeof(crc_send));

	memset(ptrdata, 0 ,string_len);
	memcpy(ptrdata, padded_msg, padded_len + sizeof(crc_send));


	PRINTF("Encrypted Message+CRC: ");
			for(int i=0; i<padded_len+sizeof(crc_send); i++) {
				PRINTF("0x%02x,", padded_msg[i]);
			}
			PRINTF("\r\n");

    uint16_t total_len = padded_len+sizeof(crc_send);

	/*Se manda nuetros datos a traves de TCP */
     err = netconn_write(newconn, ptrdata, total_len, NETCONN_COPY);
     PRINTF("netconn_write returns: %d\r\n",err);




    PRINTF("CRC-32: 0x%08x\r\n", crc_send);
    if (crc_send != checkCrc32)
    {
        PRINTF("...Check fail. Expected: 0x%x\r\n", checkCrc32);
    }


}

