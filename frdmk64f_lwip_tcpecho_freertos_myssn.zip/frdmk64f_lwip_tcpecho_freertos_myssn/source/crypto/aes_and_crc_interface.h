/*
 * aes_and_crc_interface.h
 *
 *  Created on: 17 sep 2022
 *      Author: luisf
 */

#ifndef CRYPTO_AES_AND_CRC_INTERFACE_H_
#define CRYPTO_AES_AND_CRC_INTERFACE_H_

#include "stdbool.h"



bool aescrc_receive_task(void *arg, void *ptrdata);


#endif /* CRYPTO_AES_AND_CRC_INTERFACE_H_ */
