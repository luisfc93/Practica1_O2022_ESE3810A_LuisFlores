/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2016-2019 NXP
 * All rights reserved.
 *
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include "lwip/opt.h"

#if LWIP_NETCONN

#include "board.h"
#include "aes_and_crc.h"
#include "init.h"
#include "tcpecho.h"




/*!
 * @brief Main function
 */
int main(void)
{
	/* Configuracion incial de la red */
	net_conect();
	/* Se inicializa el TCP y se ejecutan sus tareas*/
    tcpecho_init();

    //Scheduler
    vTaskStartScheduler();

    /* Will not get here unless a task calls vTaskEndScheduler ()*/
    return 0;
}
#endif

